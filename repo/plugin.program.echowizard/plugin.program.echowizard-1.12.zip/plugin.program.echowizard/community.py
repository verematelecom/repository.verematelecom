import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys
import urllib2,urllib
import extract
import downloader
import requests
import re
import plugintools
import common as Common
import installer

AddonData = xbmc.translatePath('special://userdata/addon_data')
addon_id = 'plugin.program.echowizard'
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ADDON = xbmcaddon.Addon(id=addon_id)
AddonTitle="[COLOR lime]ECHO[/COLOR] [COLOR white]Wizard[/COLOR]"
MaintTitle="[COLOR lime]ECHO[/COLOR] [COLOR white]Maintenance Tools[/COLOR]"
BASEURL = base64.b64decode(b'aHR0cDovL2VjaG9jb2Rlci5jby51ay8=')
key = base64.b64encode(plugintools.get_setting("beta"))
COMMUNITY_ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/community.png'))
Community_List = BASEURL + base64.b64decode(b"Y29tbXVuaXR5L3BhZ2U=")
Protected_List = BASEURL + base64.b64decode(b"Y29tbXVuaXR5L3Byb3RlY3RlZC9wYWdl")
COM_NOTICE = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/community_notice.txt'))
SEARCH_ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/search.png'))
page_number = 1
dialog = xbmcgui.Dialog()

#######################################################################
#######################################################################
#						Community Builds
#######################################################################

def COMMUNITY():

	link = Common.OPEN_URL(Community_List+str(page_number)+".txt").replace('\n','').replace('\r','')
	match = re.compile('name="(.+?)".+?rl="(.+?)".+?rotected="(.+?)".+?mg="(.+?)".+?anart="(.+?)"').findall(link)
	for name,url,hidden,iconimage,fanart in match:
		developer1 = str(name.replace('[COLOR white][B]',''))
		developer2 = str(developer1.replace('[/B][/COLOR]',''))
		developer = developer2.replace(' BUILDS','')
		description = str(developer + "," + hidden)
		bname = " | [COLOR white] This Week:[/COLOR][COLOR lightskyblue][B] " + str(Common.community_dev_week(developer)) + "[/B][/COLOR]"
		Common.addDir("[COLOR ghostwhite]" + name + "[/COLOR]"  + bname,url,93,iconimage,fanart,description)
	Common.addDir('[COLOR red][B]PROTECTED BUILDS[/B][/COLOR]',BASEURL,141,COMMUNITY_ICON,FANART,'')
	
	link = Common.OPEN_URL(Community_List+"s.txt").replace('\n','').replace('\r','')
	match = re.compile('pages="(.+?)').findall(link)
	for total_pages in match:
		pages = int(total_pages)
		if page_number < pages:
			description = str(page_number + 1)
			Common.addDir('[COLOR dodgerblue][B]SEARCH THE COMMUNITY BUILDS[/B][/COLOR]',BASEURL,65,SEARCH_ICON,FANART,'')
			Common.addDir('[COLOR dodgerblue][B]--------> Next Page (' + str(page_number) + ' of ' + str(pages) + ')[/COLOR][/B]',BASEURL,140,COMMUNITY_ICON,FANART,description)
		else:
			Common.addItem('[B][COLOR lightskyblue]HOW TO ADD YOUR BUILDS TO THE LIST[/COLOR][/B]',BASEURL,17,COMMUNITY_ICON,FANART,'')

def NEXT_PAGE_COMMUNITY(page_num):

	page_number = int(page_num)
	link = Common.OPEN_URL(Community_List+str(page_num)+".txt").replace('\n','').replace('\r','')
	match = re.compile('name="(.+?)".+?rl="(.+?)".+?rotected="(.+?)".+?mg="(.+?)".+?anart="(.+?)"').findall(link)
	for name,url,hidden,iconimage,fanart in match:
		developer1 = str(name.replace('[COLOR white][B]',''))
		developer2 = str(developer1.replace('[/B][/COLOR]',''))
		developer = developer2.replace(' BUILDS','')
		description = str(developer + "," + hidden)
		bname = " | [COLOR white] This Week:[/COLOR][COLOR lightskyblue][B] " + str(Common.community_dev_week(developer)) + "[/B][/COLOR]"
		Common.addDir("[COLOR ghostwhite]" + name + "[/COLOR]"  + bname,url,93,iconimage,fanart,description)
	Common.addDir('[COLOR red][B]PROTECTED BUILDS[/B][/COLOR]',BASEURL,141,COMMUNITY_ICON,FANART,'')

	link = Common.OPEN_URL(Community_List+"s.txt").replace('\n','').replace('\r','')
	match = re.compile('pages="(.+?)').findall(link)
	for total_pages in match:
		pages = int(total_pages)
		if page_number < pages:
			if page_number > 1:
				description = str(page_number + 1)
				Common.addDir('[COLOR dodgerblue][B]--------> Next Page (' + str(page_number) + ' of ' + str(pages) + ')[/COLOR][/B]',BASEURL,140,COMMUNITY_ICON,FANART,description)
				description = str(page_number - 1)
				Common.addDir('[COLOR dodgerblue][B]<-------- Previous Page (' + str(page_number) + ' of ' + str(pages) + ')[/COLOR][/B]',BASEURL,140,COMMUNITY_ICON,FANART,description)
			else:
				description = str(page_number + 1)
				Common.addDir('[COLOR dodgerblue][B]--------> Next Page (' + str(page_number) + ' of ' + str(pages) + ')[/COLOR][/B]',BASEURL,140,COMMUNITY_ICON,FANART,description)
				Common.addItem('[B][COLOR lightskyblue]There are ' + str(pages) + ' pages of community builds.[/COLOR][/B]',BASEURL,17,COMMUNITY_ICON,FANART,'')
		else:
			description = str(page_number - 1)
			Common.addDir('[COLOR dodgerblue][B]<-------- Previous Page (' + str(page_number) + ' of ' + str(pages) + ')[/COLOR][/B]',BASEURL,140,COMMUNITY_ICON,FANART,description)
			Common.addItem('[B][COLOR lightskyblue]HOW TO ADD YOUR BUILDS TO THE LIST[/COLOR][/B]',BASEURL,17,COMMUNITY_ICON,FANART,'')

def SHOWCOMMUNITYBUILDS(name, url, description):

	try:
		desca = description
		developer = desca.split(',')[0]
		hidden = desca.split(',')[1]

		if "PROTECTED" in name:
			vq = Common._get_keyboard( heading="Please Enter Your Password" )
			if ( not vq ): return False, 0
			title = vq

			AUTH = BASEURL + "community/protected/" + desca + '.txt'
			link = Common.OPEN_URL(AUTH).replace('\n','').replace('\r','')
			match = re.compile('passkey="(.+?)"').findall(link)
			for passkey in match:
				if title!=passkey:
					dialog.ok(AddonTitle, "Sorry the password entered was not found.",'[COLOR smokewhite]Thank you for using ECHO Wizard[/COLOR]')
					sys.exit(0)
	
		found = 0
		link = Common.OPEN_URL(url).replace('\n','').replace('\r','')
		match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?kin="(.+?)"').findall(link)
		for name,url,iconimage,fanart,skin in match:
			found = 1
			description = skin + "," + developer
			name = "[COLOR ghostwhite][B]" + name + "[/B][/COLOR]"
			bname = "- [COLOR white]Downloads:[/COLOR] [COLOR lightskyblue][B]" + str(Common.count_community(name)) + "[/B][/COLOR]"
			Common.addDir(name + bname,url,97,iconimage,fanart,description)
		if found == 0:
			link = Common.OPEN_URL(url).replace('\n','').replace('\r','')
			match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)"').findall(link)
			for name,url,iconimage,fanart in match:
				found = 1
				description = "null" + "," + developer
				name = "[COLOR ghostwhite][B]" + name + "[/B][/COLOR]"
				bname = "- [COLOR white]Downloads:[/COLOR] [COLOR lightskyblue][B]" + str(Common.count_community(name)) + "[/B][/COLOR]"
				Common.addDir(name + bname,url,97,iconimage,fanart,description)
			
		try:
			f = open(COM_NOTICE,mode='r'); msg = f.read(); f.close()
			Common.TextBoxesPlain("%s" % msg)
		except: pass
	except:
		dialog.ok(AddonTitle, "[COLOR red][B]We have encountered an error whilst trying to connect to the ECHO servers. Some functionality in the wizard may be off line but most things like maintenance should still work.[/B][/COLOR]")
		sys.exit(1)

def PROTECTED_FOLDER():

	link = Common.OPEN_URL(Protected_List+str(page_number)+".txt").replace('\n','').replace('\r','')
	match = re.compile('name="(.+?)".+?rl="(.+?)".+?rotected="(.+?)".+?mg="(.+?)".+?anart="(.+?)"').findall(link)
	for name,url,hidden,iconimage,fanart in match:
		developer1 = str(name.replace('[COLOR white][B]',''))
		developer2 = str(developer1.replace('[/B][/COLOR]',''))
		developer = developer2.replace(' BUILDS','')
		description = str(developer + "," + hidden)
		bname = " | [COLOR white] Week:[/COLOR][COLOR lightskyblue][B] " + str(Common.community_dev_week(developer)) + "[/B][/COLOR]"
		Common.addDir("[COLOR ghostwhite]" + name + "[/COLOR]" +  bname,url,143,iconimage,fanart,description)
	
	link = Common.OPEN_URL(Protected_List+"s.txt").replace('\n','').replace('\r','')
	match = re.compile('pages="(.+?)').findall(link)
	for total_pages in match:
		pages = int(total_pages)
		if page_number < pages:
			description = str(page_number + 1)
			Common.addItem('[COLOR ghostwhite]----------------------------------------------------[/COLOR]',BASEURL,17,COMMUNITY_ICON,FANART,'')
			Common.addDir('[COLOR dodgerblue][B]--------> Next Page (' + str(page_number) + ' of ' + str(pages) + ')[/COLOR][/B]',BASEURL,142,COMMUNITY_ICON,FANART,description)
			Common.addItem('[B][COLOR lightskyblue]There are ' + str(pages) + ' pages of community builds.[/COLOR][/B]',BASEURL,17,COMMUNITY_ICON,FANART,'')
		else:
			Common.addItem('[B][COLOR lightskyblue]HOW TO ADD YOUR BUILDS TO THE LIST[/COLOR][/B]',BASEURL,17,COMMUNITY_ICON,FANART,'')

def NEXT_PAGE_PROTECTED(page_num):

	page_number = int(page_num)
	link = Common.OPEN_URL(Protected_List+str(page_num)+".txt").replace('\n','').replace('\r','')
	match = re.compile('name="(.+?)".+?rl="(.+?)".+?rotected="(.+?)".+?mg="(.+?)".+?anart="(.+?)"').findall(link)
	for name,url,hidden,iconimage,fanart in match:
		developer1 = str(name.replace('[COLOR white][B]',''))
		developer2 = str(developer1.replace('[/B][/COLOR]',''))
		developer = developer2.replace(' BUILDS','')
		description = str(developer + "," + hidden)
		bname = " | [COLOR white] Week:[/COLOR][COLOR lightskyblue][B] " + str(Common.community_dev_week(developer)) + "[/B][/COLOR]"
		Common.addDir("[COLOR ghostwhite]" + name + "[/COLOR]" + bname,url,143,iconimage,fanart,description)

	link = Common.OPEN_URL(Protected_List+"s.txt").replace('\n','').replace('\r','')
	match = re.compile('pages="(.+?)').findall(link)
	for total_pages in match:
		pages = int(total_pages)
		if page_number < pages:
			if page_number > 1:
				Common.addItem('[COLOR ghostwhite]----------------------------------------------------[/COLOR]',BASEURL,17,COMMUNITY_ICON,FANART,'')
				description = str(page_number + 1)
				Common.addDir('[COLOR dodgerblue][B]--------> Next Page (' + str(page_number) + ' of ' + str(pages) + ')[/COLOR][/B]',BASEURL,141,COMMUNITY_ICON,FANART,description)
				description = str(page_number - 1)
				Common.addDir('[COLOR dodgerblue][B]<-------- Previous Page (' + str(page_number) + ' of ' + str(pages) + ')  <----[/COLOR][/B]',BASEURL,142,COMMUNITY_ICON,FANART,description)
			else:
				Common.addItem('[COLOR ghostwhite]----------------------------------------------------[/COLOR]',BASEURL,17,COMMUNITY_ICON,FANART,'')
				description = str(page_number + 1)
				Common.addDir('[COLOR dodgerblue][B]--------> Next Page (' + str(page_number) + ' of ' + str(pages) + ')[/COLOR][/B]',BASEURL,141,COMMUNITY_ICON,FANART,description)
				Common.addItem('[B][COLOR lightskyblue]There are ' + str(pages) + ' pages of community builds.[/COLOR][/B]',BASEURL,17,COMMUNITY_ICON,FANART,'')
		else:
			description = str(page_number - 1)
			Common.addDir('[COLOR dodgerblue][B]<-------- Previous Page (' + str(page_number) + ' of ' + str(pages) + ')  <----[/COLOR][/B]',BASEURL,142,COMMUNITY_ICON,FANART,description)
			Common.addItem('[B][COLOR lightskyblue]HOW TO ADD YOUR BUILDS TO THE LIST[/COLOR][/B]',BASEURL,17,COMMUNITY_ICON,FANART,'')

def SHOWPROTECTEDBUILDS(name, url, description):

	desca = description
	developer = desca.split(',')[0]
	hidden = desca.split(',')[1]
	vq = Common._get_keyboard( heading="Please Enter Your Password" )
	if ( not vq ): return False, 0
	title = vq

	AUTH = BASEURL + "community/protected/" + hidden + '.txt'
	link = Common.OPEN_URL(AUTH).replace('\n','').replace('\r','')
	match = re.compile('passkey="(.+?)"').findall(link)
	for passkey in match:
		if title!=passkey:
			dialog.ok(AddonTitle, "Sorry the password entered was not found.",'[COLOR smokewhite]Thank you for using ECHO Wizard[/COLOR]')
			sys.exit(0)
	
	found = 0
	link = Common.OPEN_URL(url).replace('\n','').replace('\r','')
	match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?kin="(.+?)"').findall(link)
	for name,url,iconimage,fanart,skin in match:
		found = 1
		description = skin + "," + developer
		name = "[COLOR ghostwhite][B]" + name + "[/B][/COLOR]"
		bname = "- [COLOR white]Downloads:[/COLOR] [COLOR lightskyblue][B]" + str(Common.count_community(name)) + "[/B][/COLOR]"
		Common.addDir(name + bname,url,97,iconimage,fanart,description)
	if found == 0:
		link = Common.OPEN_URL(url).replace('\n','').replace('\r','')
		match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)"').findall(link)
		for name,url,iconimage,fanart in match:
			found = 1
			description = "null" + "," + developer
			name = "[COLOR ghostwhite][B]" + name + "[/B][/COLOR]"
			bname = "- [COLOR white]Downloads:[/COLOR] [COLOR lightskyblue][B]" + str(Common.count_community(name)) + "[/B][/COLOR]"
			Common.addDir(name + bname,url,97,iconimage,fanart,description)

	try:
		f = open(COM_NOTICE,mode='r'); msg = f.read(); f.close()
		Common.TextBoxesPlain("%s" % msg)
	except: pass

#######################################################################
#                       Community
#######################################################################
def CommunityBuilds():
    
    dialog = xbmcgui.Dialog()
    dialog.ok(AddonTitle, "[COLOR white]If you would like your build to be hosted by[/COLOR]", "[COLOR ghostwhite]ECHO[/COLOR] [COLOR lightsteelblue]WIZARD[/COLOR]  [COLOR white]please visit:[/COLOR]", "[COLOR smokewhite]http://www.echocoder.com/forum [/COLOR]")
