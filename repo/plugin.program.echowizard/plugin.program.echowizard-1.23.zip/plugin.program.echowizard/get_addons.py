"""
    Copyright (C) 2016 ECHO Wizard

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys,xbmcvfs
import shutil
import base64
import re
import shutil
import time
import common as Common
import downloader
import zipfile
import urllib,urllib2

dialog           = xbmcgui.Dialog()
AddonTitle       ="[COLOR lime]ECHO[/COLOR] [COLOR white]Wizard[/COLOR]"
addon_id         = 'plugin.program.echowizard'
FANART           = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON             = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
XXX_ICON         = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/xxx.png'))
VIDEO_ICON       = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/video.png'))
TOP_ICON         = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/top.png'))
SUPPORT_ICON     = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/support_installer.png'))
PROGRAM_ICON     = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/program.png'))
PICTURE_ICON     = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/picture.png'))
PC_ICON          = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/pc.png'))
PAID_ICON        = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/paid.png'))
PACKS_ICON       = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/packs.png'))
MUSIC_ICON       = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/music.png'))
DEP_ICON         = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/dependencies.png'))
ALL_ICON         = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/all.png'))
UPDATE_ICON      = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/updates.png'))
ADDON_DATA       = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/' + addon_id, 'packs/'))
PARENTAL_FILE    = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/' + addon_id , 'controls.txt'))
PARENTAL_FOLDER  = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/' + addon_id))
BASEURL          = base64.b64decode(b'aHR0cDovL3RkYnJlcG8uY29tLw==')
ADDON_LIST       = BASEURL + base64.b64decode(b'YWRkb25zL2FkZG9uX2xpc3RfbmV3LnhtbA==')
ADDON_LIST_PAID  = BASEURL + base64.b64decode(b'YWRkb25zL2FkZG9uX2xpc3RfcGFpZC54bWw=')
DEPENDENCIES     = BASEURL + base64.b64decode(b'YWRkb25zL2RlcGVuZGVuY2llc19saXN0LnhtbA==')
PASSWD           = BASEURL + base64.b64decode(b'b3RoZXIvYWR1bHRwYXNzLnR4dA==')
PACKS_LIST       = BASEURL + base64.b64decode(b'YWRkb25zL2FkZG9uX3BhY2tzLnhtbA==')
DEP_LIST         = BASEURL + base64.b64decode(b'YWRkb25zL2RlcHMueG1s')
PAID_DESC        = BASEURL + base64.b64decode(b'YWRkb25zL3BhaWRfZGVzY3JpcHRpb25zLw==')
USER_AGENT       = base64.b64decode(b'VGhlV2l6YXJkSXNIZXJl')

def MENU():

	if os.path.exists(PARENTAL_FILE):
		vq = Common._get_keyboard( heading="Please Enter Your Password" )
		if ( not vq ): 
			dialog.ok(AddonTitle,"Sorry, no password was entered.")
			sys.exit(0)
		pass_one = vq

		vers = open(PARENTAL_FILE, "r")
		regex = re.compile(r'<password>(.+?)</password>')
		for line in vers:
			file = regex.findall(line)
			for current_pin in file:
				password = base64.b64decode(current_pin)
				if not password == pass_one:
					dialog.ok(AddonTitle,"Sorry, the password you entered was incorrect.")
					sys.exit(0)

	Common.addDir("[COLOR white][B]All Addons[/B][/COLOR]",BASEURL,150,ALL_ICON,FANART,description='all')
	Common.addDir("[COLOR white][B]Over 100 downloads this week[/B][/COLOR]",BASEURL,150,TOP_ICON,FANART,description='top')
	Common.addDir("[COLOR white][B]Video Addons[/B][/COLOR]",BASEURL,150,VIDEO_ICON,FANART,description='video')
	Common.addDir("[COLOR white][B]Program Addons[/B][/COLOR]",BASEURL,150,PROGRAM_ICON,FANART,description='program')
	Common.addDir("[COLOR white][B]Music Addons[/B][/COLOR]",BASEURL,150,MUSIC_ICON,FANART,description='audio')
	Common.addDir("[COLOR white][B]Picture Addons[/B][/COLOR]",BASEURL,150,PICTURE_ICON,FANART,description='image')
	Common.addDir("[COLOR white][B]Adult (XXX) Addons[/B][/COLOR]",BASEURL,150,XXX_ICON,FANART,description='xxx')
	Common.addDir("[COLOR powderblue][B]Addon Packs[/B][/COLOR]",BASEURL,150,PACKS_ICON,FANART,description='packs')
	Common.addDir("[COLOR powderblue][B]Addon Dependencies[/B][/COLOR]",BASEURL,150,DEP_ICON,FANART,description='dep')
	Common.addDir("[COLOR orangered][B][I]Paid IPTV Addons with Price Lists.[/I][/B][/COLOR]",BASEURL,150,PAID_ICON,FANART,description='paid')
	Common.addItem("[COLOR dodgerblue][B]How To Contact ECHO[/B][/COLOR]",BASEURL,152,SUPPORT_ICON,FANART,'')
	Common.addItem("[COLOR dodgerblue][B]How To Get an Addon Added[/B][/COLOR]",BASEURL,153,SUPPORT_ICON,FANART,'')

	if not os.path.exists(PARENTAL_FILE):
		Common.addDir("[COLOR orangered][B]PARENTAL CONTROLS - [COLOR red]OFF[/COLOR][/B][/COLOR]","url",159,PC_ICON,FANART,'')
	else:
		Common.addDir("[COLOR orangered][B]PARENTAL CONTROLS - [COLOR lime]ON[/COLOR][/B][/COLOR]","url",159,PC_ICON,FANART,'')

	xbmc.executebuiltin('Container.SetViewMode(50)')

def GET_LIST(description):

	matcher = description
	
	SOURCES     =  xbmc.translatePath(os.path.join('special://home/userdata','sources.xml'))

	if not os.path.isfile(SOURCES):
		f = open(SOURCES,'w')
		f.write('<sources>\n    <files>\n        <default pathversion="1"></default>\n    </files>\n</sources>')
		f.close()

	if matcher == "packs":
		try:
			url = PACKS_LIST
			url2 = PACKS_LIST
			link = open_url(url)
			match= re.compile('<item>(.+?)</item>').findall(link)
			for item in sorted(match):
				if '<link>' in item:
					links=re.compile('<link>(.+?)</link>').findall(item)
					if len(links)>1:
						name=re.compile('<title>(.+?)</title>').findall(item)[0]
						addon_path=re.compile('<addon_path>(.+?)</addon_path>').findall(item)[0]
						repo_path=re.compile('<repo_path>(.+?)</repo_path>').findall(item)[0]
						iconimage=re.compile('<iconimage>(.+?)</iconimage>').findall(item)[0]
						fanart=re.compile('<fanart>(.+?)</fanart>').findall(item)[0]     
						ADDON  =  xbmc.translatePath(os.path.join('special://home/addons',addon_path))
						REPO   =  xbmc.translatePath(os.path.join('special://home/addons',repo_path))
						base_name = name
						url2 = addon_path + "," + repo_path + "," + base_name  + "," + url
						count = str(Common.count_addons_week(name))
						bname = " | [COLOR white] This Week:[/COLOR][COLOR lightskyblue][B] " + count + "[/B][/COLOR]"
						CHECK_PATH = xbmc.translatePath(os.path.join(ADDON_DATA,addon_path + '.txt'))
						if not os.path.exists(CHECK_PATH):
							Common.addItem("[COLOR white][B]" + base_name + " - NOT INSTALLED[/B][/COLOR]" + bname,url2,151,iconimage,fanart,'')
						else:
							Common.addItem("[COLOR lightskyblue][B]" + base_name + " - INSTALLED[/B][/COLOR]" + bname,url2,151,iconimage,fanart,'')
		except:
			dialog.ok(AddonTitle, "[COLOR red][B]We have encountered an error whilst trying to connect to the ECHO servers. Some functionality in the wizard may be off line but most things like maintenance should still work.[/B][/COLOR]")
			sys.exit(0) 

	elif matcher == "top":
		try:
			found_one = 0
			url = ADDON_LIST
			url2 = ADDON_LIST
			link = open_url(url)
			match= re.compile('<item>(.+?)</item>').findall(link)
			for item in sorted(match):
				if '<link>' in item:
					links=re.compile('<link>(.+?)</link>').findall(item)
					if len(links)>1:
						name=re.compile('<title>(.+?)</title>').findall(item)[0]
						addon_path=re.compile('<addon_path>(.+?)</addon_path>').findall(item)[0]
						repo_path=re.compile('<repo_path>(.+?)</repo_path>').findall(item)[0]
						iconimage=re.compile('<iconimage>(.+?)</iconimage>').findall(item)[0]
						fanart=re.compile('<fanart>(.+?)</fanart>').findall(item)[0]     
						ADDON  =  xbmc.translatePath(os.path.join('special://home/addons',addon_path))
						REPO   =  xbmc.translatePath(os.path.join('special://home/addons',repo_path))
						base_name = name
						url2 = addon_path + "," + repo_path + "," + base_name  + "," + url
						count = str(Common.count_addons_week(name))
						check = int(float(count))
						bname = " | [COLOR white] This Week:[/COLOR][COLOR lightskyblue][B] " + count + "[/B][/COLOR]"
						if check > 100:
							found_one = 1
							if not os.path.exists(ADDON):
								Common.addItem("[COLOR white][B]" + base_name + " - NOT INSTALLED[/B][/COLOR]" + bname,url2,151,iconimage,fanart,'')
							else:
								Common.addItem("[COLOR lightskyblue][B]" + base_name + " - INSTALLED[/B][/COLOR]" + bname,url2,151,iconimage,fanart,'')
			if found_one == 0:
				dialog.ok(AddonTitle, "[COLOR red][B]Sorry, there are no addons with over 100 downloads this week at the moment.[/B][/COLOR]")
		except:
			dialog.ok(AddonTitle, "[COLOR red][B]We have encountered an error whilst trying to connect to the ECHO servers. Some functionality in the wizard may be off line but most things like maintenance should still work.[/B][/COLOR]")
			sys.exit(0) 

	elif matcher == "paid":
		try:
			url = ADDON_LIST_PAID
			url2 = ADDON_LIST_PAID
			link = open_url(url)
			match= re.compile('<item>(.+?)</item>').findall(link)
			# This functions sends a loop for every <item> you have in  the list.
			for item in sorted(match):
				# Try the following, if there is an error it will pass and not show any errors.
				#If the item is a sportsdevil link.
				if '<link>' in item:
					links=re.compile('<link>(.+?)</link>').findall(item)
					# Count how many sportsdevil tags there are to determain if its a single or multi link.
					if len(links)>1:
						name=re.compile('<title>(.+?)</title>').findall(item)[0]
						addon_path=re.compile('<addon_path>(.+?)</addon_path>').findall(item)[0]
						repo_path=re.compile('<repo_path>(.+?)</repo_path>').findall(item)[0]
						iconimage=re.compile('<iconimage>(.+?)</iconimage>').findall(item)[0]
						fanart=re.compile('<fanart>(.+?)</fanart>').findall(item)[0]     
						ADDON  =  xbmc.translatePath(os.path.join('special://home/addons',addon_path))
						REPO   =  xbmc.translatePath(os.path.join('special://home/addons',repo_path))
						base_name = name
						url2 = addon_path + "," + repo_path + "," + base_name  + "," + url
						bname = " | [COLOR white] This Week:[/COLOR][COLOR lightskyblue][B] " + str(Common.count_addons_week(name)) + "[/B][/COLOR]"
						if not os.path.exists(ADDON):
							Common.addItem("[COLOR white][B]" + name + " - NOT INSTALLED[/B][/COLOR]" + bname,url2,156,iconimage,fanart,'')
						else:
							Common.addItem("[COLOR lightskyblue][B]" + name + " - INSTALLED[/B][/COLOR]" + bname,url2,156,iconimage,fanart,'')
		except:
			dialog.ok(AddonTitle, "[COLOR red][B]We have encountered an error whilst trying to connect to the ECHO servers. Some functionality in the wizard may be off line but most things like maintenance should still work.[/B][/COLOR]")
			sys.exit(1) 
	elif matcher == "dep":
		xbmc.executebuiltin('Container.SetViewMode(50)')
		url = DEP_LIST
		url2 = DEP_LIST
		link = open_url(url)
		match= re.compile('<item>(.+?)</item>').findall(link)
		# This functions sends a loop for every <item> you have in  the list.
		for item in sorted(match):
			# Try the following, if there is an error it will pass and not show any errors.
			#If the item is a sportsdevil link.
			if '<link>' in item:
				links=re.compile('<link>(.+?)</link>').findall(item)
				# Count how many sportsdevil tags there are to determain if its a single or multi link.
				if len(links)>1:
					name=re.compile('<title>(.+?)</title>').findall(item)[0]
					iconimage=re.compile('<iconimage>(.+?)</iconimage>').findall(item)[0]
					fanart=re.compile('<fanart>(.+?)</fanart>').findall(item)[0]     
					repo_path = "nothing"
					addon_path = str(name)
					ADDON  =  xbmc.translatePath(os.path.join('special://home/addons',addon_path))
					REPO   =  xbmc.translatePath(os.path.join('special://home/addons',repo_path))
					base_name = name
					url2 = addon_path + "," + repo_path + "," + base_name  + "," + url
					bname = " | [COLOR white] This Week:[/COLOR][COLOR lightskyblue][B] " + str(Common.count_addons_week(name)) + "[/B][/COLOR]"
					if not os.path.exists(ADDON):
						Common.addItem("[COLOR white][B]" + name + " - NOT INSTALLED[/B][/COLOR]" + bname,url2,151,iconimage,fanart,'')
					else:
						Common.addItem("[COLOR lightskyblue][B]" + name + " - INSTALLED[/B][/COLOR]" + bname,url2,151,iconimage,fanart,'')

#		except:
#			dialog.ok(AddonTitle, "[COLOR red][B]We have encountered an error whilst trying to connect to the ECHO servers. Some functionality in the wizard may be off line but most things like maintenance should still work.[/B][/COLOR]")
#			sys.exit(1) 
	else:
		try:
			url = ADDON_LIST
			url2 = ADDON_LIST
			link = open_url(url)
			match= re.compile('<item>(.+?)</item>').findall(link)
			# This functions sends a loop for every <item> you have in  the list.
			for item in sorted(match):
				# Try the following, if there is an error it will pass and not show any errors.
				#If the item is a sportsdevil link.
				if '<link>' in item:
					links=re.compile('<link>(.+?)</link>').findall(item)
					# Count how many sportsdevil tags there are to determain if its a single or multi link.
					if len(links)>1:
						name=re.compile('<title>(.+?)</title>').findall(item)[0]
						addon_path=re.compile('<addon_path>(.+?)</addon_path>').findall(item)[0]
						repo_path=re.compile('<repo_path>(.+?)</repo_path>').findall(item)[0]
						iconimage=re.compile('<iconimage>(.+?)</iconimage>').findall(item)[0]
						fanart=re.compile('<fanart>(.+?)</fanart>').findall(item)[0]     
						ADDON  =  xbmc.translatePath(os.path.join('special://home/addons',addon_path))
						REPO   =  xbmc.translatePath(os.path.join('special://home/addons',repo_path))
						base_name = name
						url2 = addon_path + "," + repo_path + "," + base_name  + "," + url
						bname = " | [COLOR white] This Week:[/COLOR][COLOR lightskyblue][B] " + str(Common.count_addons_week(name)) + "[/B][/COLOR]"
						if matcher == "xxx":
							if matcher in name.lower():
								if not os.path.exists(ADDON):
									Common.addItem("[COLOR white][B]" + name + " - NOT INSTALLED[/B][/COLOR]" + bname,url2,151,iconimage,fanart,'')
								else:
									Common.addItem("[COLOR lightskyblue][B]" + name + " - INSTALLED[/B][/COLOR]" + bname,url2,151,iconimage,fanart,'')
						elif matcher != "all":
							if matcher in addon_path:
								if not os.path.exists(ADDON):
									Common.addItem("[COLOR white][B]" + name + " - NOT INSTALLED[/B][/COLOR]" + bname,url2,151,iconimage,fanart,'')
								else:
									Common.addItem("[COLOR lightskyblue][B]" + name + " - INSTALLED[/B][/COLOR]" + bname,url2,151,iconimage,fanart,'')
						else:
							if not os.path.exists(ADDON):
								Common.addItem("[COLOR white][B]" + name + " - NOT INSTALLED[/B][/COLOR]" + bname,url2,151,iconimage,fanart,'')
							else:
								Common.addItem("[COLOR lightskyblue][B]" + name + " - INSTALLED[/B][/COLOR]" + bname,url2,151,iconimage,fanart,'')
		except:
			dialog.ok(AddonTitle, "[COLOR red][B]We have encountered an error whilst trying to connect to the ECHO servers. Some functionality in the wizard may be off line but most things like maintenance should still work.[/B][/COLOR]")
			sys.exit(1) 

	if matcher == "dep":
		xbmc.executebuiltin('Container.SetViewMode(50)')
	else:
		xbmc.executebuiltin('Container.SetViewMode(500)')

def GET_MULTI(name,url):
	
	urla  = url
	addon_path,repo_path,base_name,url   = urla.split(',')
	get_url = url

	if 'pack' in base_name.lower():
		PATH = xbmc.translatePath(os.path.join(ADDON_DATA,addon_path + '.txt'))
		if os.path.exists(PATH):
			choice = xbmcgui.Dialog().yesno(AddonTitle, "[COLOR white]" + base_name + " is already installed.[/COLOR]","[COLOR orangered]Would you like to uninstall it now?[/COLOR]" ,yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR lightskyblue]NO[/COLOR][/B]')
			if choice == 1:
				try:
					os.remove(PATH)
				except: pass
				dialog.ok(AddonTitle,"[COLOR white]" + base_name + " has been successfully removed from your system![/COLOR]")
				sys.exit(1)
			else:
				sys.exit(0)
	else:
		ADDON  =  xbmc.translatePath(os.path.join('special://home/addons',addon_path))
		if os.path.exists(ADDON):
			choice = xbmcgui.Dialog().yesno(AddonTitle, "[COLOR white]" + base_name + " is already installed.[/COLOR]","[COLOR orangered]Would you like to uninstall it now?[/COLOR]" ,yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR lightskyblue]NO[/COLOR][/B]')
			if choice == 1:
				try:
					shutil.rmtree(ADDON)
					shutil.rmtree(REPO)
				except: pass
				dialog.ok(AddonTitle,"[COLOR white]" + base_name + " has been successfully removed from your system![/COLOR]")
				sys.exit(1)
			else:
				sys.exit(0)

	if "footballrepeat" in addon_path.lower():
		SOURCES     =  xbmc.translatePath(os.path.join('special://home/userdata','sources.xml'))
		if "archive.org/download/back2basicsrepo" not in open(SOURCES).read():
			choice = xbmcgui.Dialog().yesno(AddonTitle, "[COLOR white]" + base_name + " requires their source to be included in the file manager. We have detected that it is not currently listed in the file manager. Would you like us to automatically add it now? If you press NO installation will be cancelled.[/COLOR]", yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR lightskyblue]NO[/COLOR][/B]')
			if choice == 1:
				OLD = '<files>\n        <default pathversion="1"></default>'
				NEW = '<files>\n		<default pathversion="1"></default>\n		<source>\n			<name>Backtobasics</name>\n			<path pathversion="1">http://archive.org/download/back2basicsrepo/</path>\n			<allowsharing>true</allowsharing>\n		</source>'
				a=open(SOURCES).read()
				b=a.replace(OLD, NEW)
				f= open((SOURCES), mode='w')
				f.write(str(b))
				f.close()
			else:
				sys.exit(1)

		if "archive.org/download/back2basicsrepo" not in open(SOURCES).read():
			dialog.ok(AddonTitle, '[COLOR white]Sorry, there was an error writing the source to the file manager. We are unable to install Football Repeat at this time.[/COLOR]')
			sys.exit(1)

	choice = xbmcgui.Dialog().yesno(AddonTitle, "[COLOR white]Would you like to install " + base_name + " now?[/COLOR]", yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR lightskyblue]NO[/COLOR][/B]')
	get_dep = 1
	get_addon = 1
	if choice == 1:
		if get_dep == 1:
			try:
				streamurl=[]
				streamname=[]
				streamicon=[]
				link=open_url(DEPENDENCIES)
				urls=re.compile('<title>'+re.escape("Dependencies")+'</title>(.+?)</item>',re.DOTALL).findall(link)[0]
				iconimage=re.compile('<iconimage>(.+?)</iconimage>').findall(urls)[0]
				links=re.compile('<link>(.+?)</link>').findall(urls)
				i=1
				for sturl in links:
					sturl2=sturl
					if '(' in sturl:
						sturl=sturl.split('(')[0]
						caption=str(sturl2.split('(')[1].replace(')',''))
						streamurl.append(sturl)
						streamname.append(caption)
						ADDON  =  xbmc.translatePath(os.path.join('special://home/addons/',str(caption)))
						if not os.path.exists(ADDON):
							url = str(sturl)
							install_name = str("[COLOR lightskyblue][B]" + caption + "[/B][/COLOR]")
							INSTALL(install_name,url)
						i=i+1
			except: pass
	
		if get_addon == 1:
			try:
				streamurl=[]
				streamname=[]
				streamicon=[]
				link=open_url(get_url)
				urls=re.compile('<title>'+re.escape(base_name)+'</title>(.+?)</item>',re.DOTALL).findall(link)[0]
				links=re.compile('<link>(.+?)</link>').findall(urls)
				iconimage=re.compile('<iconimage>(.+?)</iconimage>').findall(urls)[0]
				i=1
				for sturl in links:
					sturl2=sturl
					if '(' in sturl:
						sturl=sturl.split('(')[0]
						caption=str(sturl2.split('(')[1].replace(')',''))
						streamurl.append(sturl)
						streamname.append(caption)
						ADDON  =  xbmc.translatePath(os.path.join('special://home/addons/',str(caption)))
						if not "http" in caption:
							if not os.path.exists(ADDON):
								url = str(sturl)
								install_name = str("[COLOR lightskyblue][B]" + caption + "[/B][/COLOR]")
								INSTALL(install_name,url)
						i=i+1
			except: pass
	else:
		sys.exit(1)

	add_download = Common.add_one_addons_week(base_name)
	xbmc.executebuiltin( "ActivateWindow(busydialog)" )
	xbmc.executebuiltin("UpdateAddonRepos")
	xbmc.executebuiltin("UpdateLocalAddons")
	time.sleep(2)
	xbmc.executebuiltin( "Dialog.Close(busydialog)" )

	if "pack" not in base_name.lower():
		choice = xbmcgui.Dialog().yesno(AddonTitle, "[COLOR white]" + base_name + " successfully installed![/COLOR]","[COLOR orange]Would you like to launch " + base_name + " now?[/COLOR]","" ,yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR lightskyblue]NO[/COLOR][/B]')
		if choice == 1:
			RUN = "RunAddon(" + addon_path + ")"
			xbmc.executebuiltin(RUN)
	else:
		PATH = xbmc.translatePath(os.path.join(ADDON_DATA,addon_path + '.txt'))
		if not os.path.exists(PATH):
			if not os.path.exists(ADDON_DATA):
				os.makedirs(ADDON_DATA)
			open(PATH, 'w')
		xbmcgui.Dialog().ok(AddonTitle, "[COLOR white]" + base_name + " successfully installed![/COLOR]")


def GET_PAID(name,url):
	
	urla  = url
	addon_path,repo_path,base_name,url   = urla.split(',')
	get_url = url

	ADDON  =  xbmc.translatePath(os.path.join('special://home/addons',addon_path))
	if os.path.exists(ADDON):
		choice = xbmcgui.Dialog().yesno(AddonTitle, "[COLOR white]" + base_name + " is already installed.[/COLOR]","[COLOR orangered]Would you like to uninstall it now?[/COLOR]" ,yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR lightskyblue]NO[/COLOR][/B]')
		if choice == 1:
			try:
				shutil.rmtree(ADDON)
				shutil.rmtree(REPO)
			except: pass
			dialog.ok(AddonTitle,"[COLOR white]" + base_name + " has been successfully removed from your system![/COLOR]")
			sys.exit(0)
		else:
			sys.exit(0)

	choice = xbmcgui.Dialog().yesno(AddonTitle, "[COLOR white]Would you like to download " + base_name + " or view the price list?.[/COLOR]",yeslabel='[B][COLOR orangered]DOWNLOAD[/COLOR][/B]',nolabel='[B][COLOR orangered]PRICE LIST[/COLOR][/B]')
	if choice == 0:
		url = PAID_DESC + addon_path + ".txt"
		content = open_url_desc(url)
		string = str(content)
		TextBoxes("%s" % string)
		sys.exit(0)

	choice = 1
	get_dep = 1
	get_addon = 1
	if choice == 1:
		if get_dep == 1:
			try:
				streamurl=[]
				streamname=[]
				streamicon=[]
				link=open_url(DEPENDENCIES)
				urls=re.compile('<title>'+re.escape("Dependencies")+'</title>(.+?)</item>',re.DOTALL).findall(link)[0]
				iconimage=re.compile('<iconimage>(.+?)</iconimage>').findall(urls)[0]
				links=re.compile('<link>(.+?)</link>').findall(urls)
				i=1
				for sturl in links:
					sturl2=sturl
					if '(' in sturl:
						sturl=sturl.split('(')[0]
						caption=str(sturl2.split('(')[1].replace(')',''))
						streamurl.append(sturl)
						streamname.append(caption)
						ADDON  =  xbmc.translatePath(os.path.join('special://home/addons/',str(caption)))
						if not os.path.exists(ADDON):
							url = str(sturl)
							install_name = str("[COLOR lightskyblue][B]" + caption + "[/B][/COLOR]")
							INSTALL(install_name,url)
						i=i+1
			except: pass
	
		if get_addon == 1:
			try:
				streamurl=[]
				streamname=[]
				streamicon=[]
				link=open_url(get_url)
				urls=re.compile('<title>'+re.escape(base_name)+'</title>(.+?)</item>',re.DOTALL).findall(link)[0]
				links=re.compile('<link>(.+?)</link>').findall(urls)
				iconimage=re.compile('<iconimage>(.+?)</iconimage>').findall(urls)[0]
				i=1
				for sturl in links:
					sturl2=sturl
					if '(' in sturl:
						sturl=sturl.split('(')[0]
						caption=str(sturl2.split('(')[1].replace(')',''))
						streamurl.append(sturl)
						streamname.append(caption)
						ADDON  =  xbmc.translatePath(os.path.join('special://home/addons/',str(caption)))
						if not "http" in caption:
							if not os.path.exists(ADDON):
								url = str(sturl)
								install_name = str("[COLOR lightskyblue][B]" + caption + "[/B][/COLOR]")
								INSTALL(install_name,url)
						i=i+1
			except: pass
	else:
		sys.exit(1)

	add_download = Common.add_one_addons_week(base_name)
	xbmc.executebuiltin( "ActivateWindow(busydialog)" )
	xbmc.executebuiltin("UpdateAddonRepos")
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin( "Dialog.Close(busydialog)" )

	choice = xbmcgui.Dialog().yesno(AddonTitle, "[COLOR white]" + base_name + " successfully installed![/COLOR]","[COLOR orange]Would you like to launch " + base_name + " now?[/COLOR]","" ,yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR lightskyblue]NO[/COLOR][/B]')
	if choice == 1:
		RUN = "RunAddon(" + addon_path + ")"
		xbmc.executebuiltin(RUN)

def GET_PAID(name,url):
	
	urla  = url
	addon_path,repo_path,base_name,url   = urla.split(',')
	get_url = url

	ADDON  =  xbmc.translatePath(os.path.join('special://home/addons',addon_path))
	if os.path.exists(ADDON):
		choice = xbmcgui.Dialog().yesno(AddonTitle, "[COLOR white]" + base_name + " is already installed.[/COLOR]","[COLOR orangered]Would you like to uninstall it now?[/COLOR]" ,yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR lightskyblue]NO[/COLOR][/B]')
		if choice == 1:
			try:
				shutil.rmtree(ADDON)
				shutil.rmtree(REPO)
			except: pass
			dialog.ok(AddonTitle,"[COLOR white]" + base_name + " has been successfully removed from your system![/COLOR]")
			sys.exit(0)
		else:
			sys.exit(0)

	choice = xbmcgui.Dialog().yesno(AddonTitle, "[COLOR white]Would you like to download " + base_name + " or view the price list?.[/COLOR]",yeslabel='[B][COLOR orangered]DOWNLOAD[/COLOR][/B]',nolabel='[B][COLOR orangered]PRICE LIST[/COLOR][/B]')
	if choice == 0:
		url = PAID_DESC + addon_path + ".txt"
		content = open_url_desc(url)
		string = str(content)
		TextBoxes("%s" % string)
		sys.exit(0)

	choice = 1
	get_dep = 1
	get_addon = 1
	if choice == 1:
		if get_dep == 1:
			try:
				streamurl=[]
				streamname=[]
				streamicon=[]
				link=open_url(DEPENDENCIES)
				urls=re.compile('<title>'+re.escape("Dependencies")+'</title>(.+?)</item>',re.DOTALL).findall(link)[0]
				iconimage=re.compile('<iconimage>(.+?)</iconimage>').findall(urls)[0]
				links=re.compile('<link>(.+?)</link>').findall(urls)
				i=1
				for sturl in links:
					sturl2=sturl
					if '(' in sturl:
						sturl=sturl.split('(')[0]
						caption=str(sturl2.split('(')[1].replace(')',''))
						streamurl.append(sturl)
						streamname.append(caption)
						ADDON  =  xbmc.translatePath(os.path.join('special://home/addons/',str(caption)))
						if not os.path.exists(ADDON):
							url = str(sturl)
							install_name = str("[COLOR lightskyblue][B]" + caption + "[/B][/COLOR]")
							INSTALL(install_name,url)
						i=i+1
			except: pass
	
		if get_addon == 1:
			try:
				streamurl=[]
				streamname=[]
				streamicon=[]
				link=open_url(get_url)
				urls=re.compile('<title>'+re.escape(base_name)+'</title>(.+?)</item>',re.DOTALL).findall(link)[0]
				links=re.compile('<link>(.+?)</link>').findall(urls)
				iconimage=re.compile('<iconimage>(.+?)</iconimage>').findall(urls)[0]
				i=1
				for sturl in links:
					sturl2=sturl
					if '(' in sturl:
						sturl=sturl.split('(')[0]
						caption=str(sturl2.split('(')[1].replace(')',''))
						streamurl.append(sturl)
						streamname.append(caption)
						ADDON  =  xbmc.translatePath(os.path.join('special://home/addons/',str(caption)))
						if not "http" in caption:
							if not os.path.exists(ADDON):
								url = str(sturl)
								install_name = str("[COLOR lightskyblue][B]" + caption + "[/B][/COLOR]")
								INSTALL(install_name,url)
						i=i+1
			except: pass
	else:
		sys.exit(1)

	add_download = Common.add_one_addons_week(base_name)
	xbmc.executebuiltin( "ActivateWindow(busydialog)" )
	xbmc.executebuiltin("UpdateAddonRepos")
	xbmc.executebuiltin("UpdateLocalAddons")
	time.sleep(2)
	xbmc.executebuiltin( "Dialog.Close(busydialog)" )

	choice = xbmcgui.Dialog().yesno(AddonTitle, "[COLOR white]" + base_name + " successfully installed![/COLOR]","[COLOR orange]Would you like to launch " + base_name + " now?[/COLOR]","" ,yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR lightskyblue]NO[/COLOR][/B]')
	if choice == 1:
		RUN = "RunAddon(" + addon_path + ")"
		xbmc.executebuiltin(RUN)


def INSTALL(name, url):

	#Check is the packages folder exists, if not create it.
	path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
	if not os.path.exists(path):
		os.makedirs(path)
	dp = xbmcgui.DialogProgress()
	if "repository" in url:
		dp.create(AddonTitle,"","Installing " + name,"Installing " + name)
	else:
		dp.create(AddonTitle,"","Installing " + name,"Installing " + name)

	lib=os.path.join(path, 'addon.zip')
	
	try:
		os.remove(lib)
	except:
		pass

	dialog = xbmcgui.Dialog()
	try:
		downloader.download(url, lib, dp)
	except:
		downloader.download(url, lib, dp)
	addonfolder = xbmc.translatePath(os.path.join('special://home','addons'))
	time.sleep(2)
	dp.update(0,"","Extracting Zip Please Wait","")
	unzip(lib,addonfolder,dp)
	time.sleep(1)
	try:
		os.remove(lib)
	except:
		pass

def unzip(_in, _out, dp):
	__in = zipfile.ZipFile(_in,  'r')
	
	nofiles = float(len(__in.infolist()))
	count   = 0
	
	try:
		for item in __in.infolist():
			count += 1
			update = (count / nofiles) * 100
			
			if dp.iscanceled():
				dialog = xbmcgui.Dialog()
				dialog.ok(AddonTitle, 'Extraction was cancelled.')
				
				sys.exit()
				dp.close()
			
			try:
				dp.update(int(update),'','','[COLOR dodgerblue][B]' + str(item.filename) + '[/B][/COLOR]')
				__in.extract(item, _out)
			
			except Exception, e:
				print str(e)

	except Exception, e:
		print str(e)
		return False
		
	return True 

def open_url(url):
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', USER_AGENT)
		response = urllib2.urlopen(req)
		link=response.read()
		response.close()
		link=link.replace('\n','').replace('\r','').replace('<title></title>','<title>x</title>').replace('<link></link>','<link>x</link>').replace('<fanart></fanart>','<fanart>x</fanart>').replace('<thumbnail></thumbnail>','<thumbnail>x</thumbnail>').replace('<utube>','<link>https://www.youtube.com/watch?v=').replace('</utube>','</link>')#.replace('></','>x</')
		return link
	except: pass
	
def open_url_desc(url):
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', USER_AGENT)
		response = urllib2.urlopen(req)
		link=response.read()
		response.close()
		return link
	except: pass

def PARENTAL_CONTROLS():

	found = 0
	if not os.path.exists(PARENTAL_FILE):
		found = 1
		Common.addItem("[COLOR blue][B]PARENTAL CONTROLS - [/COLOR][COLOR red]OFF[/B][/COLOR]","url",999,ICON,FANART,'')
		Common.addItem("[COLOR yellow][B]Setup Parental Password[/B][/COLOR]","url",160,ICON,FANART,'')
	else:
		vers = open(PARENTAL_FILE, "r")
		regex = re.compile(r'<password>(.+?)</password>')
		for line in vers:
			file = regex.findall(line)
			for current_pin in file:
				password = base64.b64decode(current_pin)
				found = 1
				Common.addItem("[COLOR blue][B]PARENTAL CONTROLS - [/COLOR][COLOR lime]ON[/B][/COLOR]","url",999,ICON,FANART,'')
				Common.addItem("[COLOR yellow][B]Current Password - [/COLOR][COLOR orangered]" + str(password) + "[/B][/COLOR]","url",999,ICON,FANART,'')
				Common.addItem("[COLOR lime][B]Change Password[/B][/COLOR]","url",160,ICON,FANART,'')
				Common.addItem("[COLOR red][B]Disable Password[/B][/COLOR]","url",161,ICON,FANART,'')

	if found == 0:
		Common.addItem("[COLOR blue][B]PARENTAL CONTROLS - [/COLOR][COLOR red]OFF[/B][/COLOR]","url",999,ICON,FANART,'')
		Common.addItem("[COLOR yellow][B]Setup Parental Password[/B][/COLOR]","url",160,ICON,FANART,'')

def PARENTAL_CONTROLS_PIN():

	vq = Common._get_keyboard( heading="Please Set Password" )
	if ( not vq ):
		dialog.ok(AddonTitle,"Sorry, no password was entered.")
		sys.exit(0)
	pass_one = vq

	vq = Common._get_keyboard( heading="Please Confirm Your Password" )
	if ( not vq ):
		dialog.ok(AddonTitle,"Sorry, no password was entered.")
		sys.exit(0)
	pass_two = vq
		
	if not os.path.exists(PARENTAL_FILE):
		if not os.path.exists(PARENTAL_FOLDER):
			os.makedirs(PARENTAL_FOLDER)
		open(PARENTAL_FILE, 'w')

		if pass_one == pass_two:
			writeme = base64.b64encode(pass_one)
			f = open(PARENTAL_FILE,'w')
			f.write('<password>'+str(writeme)+'</password>')
			f.close()
			dialog.ok(AddonTitle,'Your password has been set and parental controls have been enabled.')
			xbmc.executebuiltin("Container.Refresh")
		else:
			dialog.ok(AddonTitle,'The passwords do not match, please try again.')
			sys.exit(0)
	else:
		os.remove(PARENTAL_FILE)
		
		if pass_one == pass_two:
			writeme = base64.b64encode(pass_one)
			f = open(PARENTAL_FILE,'w')
			f.write('<password>'+str(writeme)+'</password>')
			f.close()
			dialog.ok(AddonTitle,'Your password has been set and parental controls have been enabled.')
			xbmc.executebuiltin("Container.Refresh")
		else:
			dialog.ok(AddonTitle,'The passwords do not match, please try again.')
			sys.exit(0)

def PARENTAL_CONTROLS_OFF():

	try:
		os.remove(PARENTAL_FILE)
		dialog.ok(AddonTitle,'Parental controls have been disabled.')
		xbmc.executebuiltin("Container.Refresh")
	except:
		dialog.ok(AddonTitle,'There was an error disabling the parental controls.')
		xbmc.executebuiltin("Container.Refresh")

def TextBoxes(announce):
	class TextBox():
		WINDOW=10147
		CONTROL_LABEL=1
		CONTROL_TEXTBOX=5
		def __init__(self,*args,**kwargs):
			xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
			self.win=xbmcgui.Window(self.WINDOW) # get window
			xbmc.sleep(500) # give window time to initialize
			self.setControls()
		def setControls(self):
			self.win.getControl(self.CONTROL_LABEL).setLabel('Price List') # set heading
			try: f=open(announce); text=f.read()
			except: text=announce
			self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
			return
	TextBox()
	while xbmc.getCondVisibility('Window.IsVisible(10147)'):
		time.sleep(.5)