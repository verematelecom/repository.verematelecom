import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys,xbmcvfs
import shutil
import base64
import re
import shutil
import time
import common as Common
import downloader
import zipfile
import urllib,urllib2

dialog           = xbmcgui.Dialog()
AddonTitle       ="[COLOR lime]ECHO[/COLOR] [COLOR white]Wizard[/COLOR]"
addon_id         = 'plugin.program.echowizard'
FANART           = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON             = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ADDON_LIST       = base64.b64decode(b'aHR0cDovL2VjaG9jb2Rlci5jby51ay9hZGRvbnMvYWRkb25fbGlzdF9uZXcueG1s')
DEPENDENCIES     = base64.b64decode(b'aHR0cDovL2VjaG9jb2Rlci5jby51ay9hZGRvbnMvZGVwZW5kZW5jaWVzX2xpc3QueG1s')
PASSWD           = base64.b64decode(b'aHR0cDovL2VjaG9jb2Rlci5jby51ay9vdGhlci9hZHVsdHBhc3MudHh0')
USER_AGENT       = base64.b64decode(b'VGhlV2l6YXJkSXNIZXJl')

def MENU():

	SOURCES     =  xbmc.translatePath(os.path.join('special://home/userdata','sources.xml'))

	if not os.path.isfile(SOURCES):
		f = open(SOURCES,'w')
		f.write('<sources>\n    <files>\n        <default pathversion="1"></default>\n    </files>\n</sources>')
		f.close()

	try:
		url = ADDON_LIST
		url2 = ADDON_LIST
		link = open_url(url)
		match= re.compile('<item>(.+?)</item>').findall(link)
		# This functions sends a loop for every <item> you have in  the list.
		for item in match:
			# Try the following, if there is an error it will pass and not show any errors.
			#If the item is a sportsdevil link.
			if '<link>' in item:
				links=re.compile('<link>(.+?)</link>').findall(item)
				# Count how many sportsdevil tags there are to determain if its a single or multi link.
					
				# If it is a single link
				if len(links)==1:
					name=re.compile('<title>(.+?)</title>').findall(item)[0]
					addon_path=re.compile('<addon_path>(.+?)</addon_path>').findall(item)[0]
					repo_path=re.compile('<repo_path>(.+?)</repo_path>').findall(item)[0]
					url_get=re.compile('<link>(.+?)</link>').findall(item)[0]
					iconimage=re.compile('<iconimage>(.+?)</iconimage>').findall(item)[0]
					fanart=re.compile('<fanart>(.+?)</fanart>').findall(item)[0] 
					ADDON  =  xbmc.translatePath(os.path.join('special://home/addons',addon_path))
					REPO   =  xbmc.translatePath(os.path.join('special://home/addons',repo_path))
					base_name = name
					url = addon_path + "," + repo_path + "," + base_name + "," + url_get
					#bname = " | [COLOR white] Week:[/COLOR][COLOR lightskyblue][B] " + str(Common.count_addons_week(name)) + "[/B][/COLOR]"
					#bname_total = "[COLOR white] - Total:[/COLOR] [COLOR lightskyblue][B]" + str(Common.count_addons_total(name)) + "[/B][/COLOR]"			
					if not os.path.exists(ADDON):
						Common.addItem("[COLOR white][B]" + name + " - NOT INSTALLED[/B][/COLOR]",url,122,iconimage,fanart,'')
					else:
						Common.addItem("[COLOR lightskyblue][B]" + name + " - INSTALLED[/B][/COLOR]",url,122,iconimage,fanart,'')
				elif len(links)>1:
					name=re.compile('<title>(.+?)</title>').findall(item)[0]
					addon_path=re.compile('<addon_path>(.+?)</addon_path>').findall(item)[0]
					repo_path=re.compile('<repo_path>(.+?)</repo_path>').findall(item)[0]
					iconimage=re.compile('<iconimage>(.+?)</iconimage>').findall(item)[0]
					fanart=re.compile('<fanart>(.+?)</fanart>').findall(item)[0]     
					ADDON  =  xbmc.translatePath(os.path.join('special://home/addons',addon_path))
					REPO   =  xbmc.translatePath(os.path.join('special://home/addons',repo_path))
					base_name = name
					url2 = addon_path + "," + repo_path + "," + base_name  + "," + url
					#bname = " | [COLOR white] Week:[/COLOR][COLOR lightskyblue][B] " + str(Common.count_addons_week(name)) + "[/B][/COLOR]"
					#bname_total = "[COLOR white] - Total:[/COLOR] [COLOR lightskyblue][B]" + str(Common.count_addons_total(name)) + "[/B][/COLOR]"
					if not os.path.exists(ADDON):
						Common.addItem("[COLOR white][B]" + name + " - NOT INSTALLED[/B][/COLOR]",url2,123,iconimage,fanart,'')
					else:
						Common.addItem("[COLOR lightskyblue][B]" + name + " - INSTALLED[/B][/COLOR]",url2,123,iconimage,fanart,'')
	except:
		dialog.ok(AddonTitle, "[COLOR red][B]We have encountered an error whilst trying to connect to the ECHO servers. Some functionality in the wizard may be off line but most things like maintenance should still work.[/B][/COLOR]")
		sys.exit(1) 
		
	xbmc.executebuiltin('Container.SetViewMode(500)')

#		link = Common.OPEN_URL(ADDON_LIST).replace('\n','').replace('\r','')
#		match = re.compile('name="(.+?)".+?ddon_path="(.+?)".+?epo_path="(.+?)".+?ddon_url="(.+?)".+?epo_url="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall(link)
#		for name,addon_path,repo_path,addon_url,repo_url,icon_image,fanart_image in match:
#			ADDON  =  xbmc.translatePath(os.path.join('special://home/addons',addon_path))
#			REPO   =  xbmc.translatePath(os.path.join('special://home/addons',repo_path))
#			base_name = name
#			url = addon_path + "," + repo_path + "," + addon_url + "," + repo_url + "," + base_name
#			bname = " | [COLOR smokewhite] Downloads:[/COLOR][COLOR white] Week:[/COLOR][COLOR smokewhite] " + str(Common.count_addons_week(name)) + "[/COLOR]"
#			bname_total = "[COLOR white] - Total:[/COLOR] [COLOR smokewhite]" + str(Common.count_addons_total(name)) + "[/COLOR]"
#			if not os.path.exists(ADDON):
#				Common.addItem("[COLOR white][B]" + name + " - NOT INSTALLED[/B][/COLOR]" + bname + bname_total,url,122,icon_image,fanart_image,'')
#			else:
#				Common.addItem("[COLOR lightskyblue][B]" + name + " - INSTALLED[/B][/COLOR]" + bname + bname_total,url,122,icon_image,fanart_image,'')
#	except:
#		dialog.ok(AddonTitle, "[B][COLOR smokewhite]Sorry, ECHO Wizard encountered an error[/COLOR][/B]",'[COLOR smokewhite]This is normally a website time out, please try again.[/COLOR]',"[B][COLOR white]Error Code:[/COLOR][COLOR lightskyblue] 0026[/COLOR][/B]")

def GET_MULTI(name,url):
	
	urla  = url
	addon_path,repo_path,base_name,url   = urla.split(',')
	get_url = url

	ADDON  =  xbmc.translatePath(os.path.join('special://home/addons',addon_path))
	if os.path.exists(ADDON):
		choice = xbmcgui.Dialog().yesno(AddonTitle, "[COLOR white]" + base_name + " is already installed.[/COLOR]","[COLOR orangered]Would you like to uninstall it now?[/COLOR]" ,yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR lightskyblue]NO[/COLOR][/B]')
		if choice == 1:
			try:
				shutil.rmtree(ADDON)
				shutil.rmtree(REPO)
			except: pass
			dialog.ok(AddonTitle,"[COLOR white]" + base_name + " has been successfully removed from your system![/COLOR]")
			xbmc.executebuiltin("Container.Refresh")
			sys.exit(1)
		else:
			sys.exit(0)

#	if "xxx" in addon_path.lower():
	
#		srtv_choice = xbmcgui.Dialog().yesno(AddonTitle, '[COLOR white]XXX addons are password protected for saftey.[/COLOR]','[COLOR blue]Contact @ECHOWizard on Twitter to obtain the password. The password will be in the pinned tweet of ECHO Wizard[/COLOR]','[B]Please press YES to continue.[/B]', yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR red]NO[/COLOR][/B]')
		
#		if srtv_choice == 0:
#			sys.exit(0)
#		vq = Common._get_keyboard( heading="Please Enter Your Password" )
#		if ( not vq ): return False, 0
#		title = vq

#		link = Common.OPEN_URL(PASSWD).replace('\n','').replace('\r','')
#		match = re.compile('password="(.+?)"').findall(link)
#		for passkey in match:
#			if not title==passkey:
#				dialog.ok(AddonTitle,"[COLOR white]Sorry the password you entered was incorrect.[/COLOR]")
#				sys.exit(0)

	if "dahenchmen" in addon_path.lower():
		SOURCES     =  xbmc.translatePath(os.path.join('special://home/userdata','sources.xml'))
		if "dahenchmen.xyz/repo" not in open(SOURCES).read():
			choice = xbmcgui.Dialog().yesno(AddonTitle, "[COLOR white]" + base_name + " requires their source to be included in the file manager. We have detected that it is not currently listed in the file manager. Would you like us to automatically add it now? If you press NO installation will be cancelled.[/COLOR]", yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR lightskyblue]NO[/COLOR][/B]')
			if choice == 1:
				OLD = '<files>\n        <default pathversion="1"></default>'
				NEW = '<files>\n		<default pathversion="1"></default>\n		<source>\n			<name>DaHenchmen</name>\n			<path pathversion="1">http://dahenchmen.xyz/repo/</path>\n			<allowsharing>true</allowsharing>\n		</source>'
				a=open(SOURCES).read()
				b=a.replace(OLD, NEW)
				f= open((SOURCES), mode='w')
				f.write(str(b))
				f.close()
			else:
				sys.exit(1)

		if "dahenchmen.xyz/repo" not in open(SOURCES).read():
			dialog.ok(AddonTitle, '[COLOR white]Sorry, there was an error writing the source to the file manager. We are unable to install Da Henchmen at this time.[/COLOR]')
			sys.exit(1)

	if "footballrepeat" in addon_path.lower():
		SOURCES     =  xbmc.translatePath(os.path.join('special://home/userdata','sources.xml'))
		if "archive.org/download/back2basicsrepo" not in open(SOURCES).read():
			choice = xbmcgui.Dialog().yesno(AddonTitle, "[COLOR white]" + base_name + " requires their source to be included in the file manager. We have detected that it is not currently listed in the file manager. Would you like us to automatically add it now? If you press NO installation will be cancelled.[/COLOR]", yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR lightskyblue]NO[/COLOR][/B]')
			if choice == 1:
				OLD = '<files>\n        <default pathversion="1"></default>'
				NEW = '<files>\n		<default pathversion="1"></default>\n		<source>\n			<name>Backtobasics</name>\n			<path pathversion="1">http://archive.org/download/back2basicsrepo/</path>\n			<allowsharing>true</allowsharing>\n		</source>'
				a=open(SOURCES).read()
				b=a.replace(OLD, NEW)
				f= open((SOURCES), mode='w')
				f.write(str(b))
				f.close()
			else:
				sys.exit(1)

		if "archive.org/download/back2basicsrepo" not in open(SOURCES).read():
			dialog.ok(AddonTitle, '[COLOR white]Sorry, there was an error writing the source to the file manager. We are unable to install Football Repeat at this time.[/COLOR]')
			sys.exit(1)

	choice = xbmcgui.Dialog().yesno(AddonTitle, "[COLOR white]Would you like to install " + base_name + " now?[/COLOR]", yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR lightskyblue]NO[/COLOR][/B]')
	get_dep = 1
	get_addon = 1
	if choice == 1:
		if get_dep == 1:
			try:
				streamurl=[]
				streamname=[]
				streamicon=[]
				link=open_url(DEPENDENCIES)
				urls=re.compile('<title>'+re.escape("Dependencies")+'</title>(.+?)</item>',re.DOTALL).findall(link)[0]
				iconimage=re.compile('<iconimage>(.+?)</iconimage>').findall(urls)[0]
				links=re.compile('<link>(.+?)</link>').findall(urls)
				i=1
				for sturl in links:
					sturl2=sturl
					if '(' in sturl:
						sturl=sturl.split('(')[0]
						caption=str(sturl2.split('(')[1].replace(')',''))
						streamurl.append(sturl)
						streamname.append(caption)
						ADDON  =  xbmc.translatePath(os.path.join('special://home/addons/',str(caption)))
						if not os.path.exists(ADDON):
							url = str(sturl)
							install_name = str("[COLOR lightskyblue][B]" + caption + "[/B][/COLOR]")
							INSTALL(install_name,url)
						i=i+1
			except: pass
	
		if get_addon == 1:
			try:
				streamurl=[]
				streamname=[]
				streamicon=[]
				link=open_url(get_url)
				urls=re.compile('<title>'+re.escape(base_name)+'</title>(.+?)</item>',re.DOTALL).findall(link)[0]
				links=re.compile('<link>(.+?)</link>').findall(urls)
				iconimage=re.compile('<iconimage>(.+?)</iconimage>').findall(urls)[0]
				i=1
				for sturl in links:
					sturl2=sturl
					if '(' in sturl:
						sturl=sturl.split('(')[0]
						caption=str(sturl2.split('(')[1].replace(')',''))
						streamurl.append(sturl)
						streamname.append(caption)
						ADDON  =  xbmc.translatePath(os.path.join('special://home/addons/',str(caption)))
						if not "http" in caption:
							if not os.path.exists(ADDON):
								url = str(sturl)
								install_name = str("[COLOR lightskyblue][B]" + caption + "[/B][/COLOR]")
								INSTALL(install_name,url)
						i=i+1
			except: pass
	else:
		sys.exit(1)

	dialog.ok(AddonTitle, base_name + " has successfully been installed")
#	add_download = Common.add_one_addons_total(base_name)
#	add_download = Common.add_one_addons_week(base_name)
	xbmc.executebuiltin( "ActivateWindow(busydialog)" )
	xbmc.executebuiltin("UpdateAddonRepos")
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("Container.Refresh")
	xbmc.executebuiltin( "Dialog.Close(busydialog)" )

def GET_SINGLE(name,url):

	urla  = url
	addon_path,repo_path,addon_url,base_name   = urla.split(',')

	if "dahenchmen" in addon_url.lower():
		SOURCES     =  xbmc.translatePath(os.path.join('special://home/userdata','sources.xml'))
		if "dahenchmen.xyz/repo" not in open(SOURCES).read():
			choice = xbmcgui.Dialog().yesno(AddonTitle, "[COLOR white]" + base_name + " requires their source to be included in the file manager. We have detected that it is not currently listed in the file manager. Would you like us to automatically add it now? If you press NO installation will be cancelled.[/COLOR]", yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR lightskyblue]NO[/COLOR][/B]')
			if choice == 1:
				OLD = '<files>\n        <default pathversion="1"></default>'
				NEW = '<files>\n		<default pathversion="1"></default>\n		<source>\n			<name>DaHenchmen</name>\n			<path pathversion="1">http://dahenchmen.xyz/repo/</path>\n			<allowsharing>true</allowsharing>\n		</source>'
				a=open(SOURCES).read()
				b=a.replace(OLD, NEW)
				f= open((SOURCES), mode='w')
				f.write(str(b))
				f.close()
			else:
				sys.exit(1)

	ADDON  =  xbmc.translatePath(os.path.join('special://home/addons',addon_path))
	if os.path.exists(ADDON):
		choice = xbmcgui.Dialog().yesno(AddonTitle, "[COLOR white]" + base_name + " is already installed.[/COLOR]","[COLOR orangered]Would you like to uninstall it now?[/COLOR]" ,yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR lightskyblue]NO[/COLOR][/B]')
		if choice == 1:
			try:
				shutil.rmtree(ADDON)
				shutil.rmtree(REPO)
			except: pass
			dialog.ok(AddonTitle,"[COLOR white]" + base_name + " has been successfully removed from your system![/COLOR]")
			xbmc.executebuiltin("Container.Refresh")
			sys.exit(1)
		else:
			sys.exit(0)
	else:
		choice = xbmcgui.Dialog().yesno(AddonTitle, "[COLOR white]Would you like to install " + base_name + " now?[/COLOR]", yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR lightskyblue]NO[/COLOR][/B]')
		if choice == 1:
			INSTALL(base_name,url)
			dialog.ok(AddonTitle, base_name + " has successfully been installed")
#			add_download = Common.add_one_addons_total(base_name)
#			add_download = Common.add_one_addons_week(base_name)
			xbmc.executebuiltin( "ActivateWindow(busydialog)" )
			xbmc.executebuiltin("UpdateAddonRepos")
			xbmc.executebuiltin("UpdateLocalAddons")
			xbmc.executebuiltin("Container.Refresh")
			xbmc.executebuiltin( "Dialog.Close(busydialog)" )
		else:
			sys.exit(0)
			xbmc.executebuiltin("Container.Refresh")


def INSTALL(name, url):

	#Check is the packages folder exists, if not create it.
	path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
	if not os.path.exists(path):
		os.makedirs(path)
	dp = xbmcgui.DialogProgress()
	if "repository" in url:
		dp.create(AddonTitle,"","Installing " + name,"Installing " + name)
	else:
		dp.create(AddonTitle,"","Installing " + name,"Installing " + name)

	lib=os.path.join(path, 'addon.zip')
	
	try:
		os.remove(lib)
	except:
		pass

	dialog = xbmcgui.Dialog()
	try:
		downloader.download(url, lib, dp)
	except:
		downloader.download(url, lib, dp)
	addonfolder = xbmc.translatePath(os.path.join('special://home','addons'))
	time.sleep(2)
	dp.update(0,"","Extracting Zip Please Wait","")
	unzip(lib,addonfolder,dp)
	time.sleep(1)
	try:
		os.remove(lib)
	except:
		pass

def unzip(_in, _out, dp):
	__in = zipfile.ZipFile(_in,  'r')
	
	nofiles = float(len(__in.infolist()))
	count   = 0
	
	try:
		for item in __in.infolist():
			count += 1
			update = (count / nofiles) * 100
			
			if dp.iscanceled():
				dialog = xbmcgui.Dialog()
				dialog.ok(AddonTitle, 'Extraction was cancelled.')
				
				sys.exit()
				dp.close()
			
			try:
				dp.update(int(update),'','','[COLOR dodgerblue][B]' + str(item.filename) + '[/B][/COLOR]')
				__in.extract(item, _out)
			
			except Exception, e:
				print str(e)

	except Exception, e:
		print str(e)
		return False
		
	return True 

def open_url(url):
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', USER_AGENT)
		response = urllib2.urlopen(req)
		link=response.read()
		response.close()
		link=link.replace('\n','').replace('\r','').replace('<title></title>','<title>x</title>').replace('<link></link>','<link>x</link>').replace('<fanart></fanart>','<fanart>x</fanart>').replace('<thumbnail></thumbnail>','<thumbnail>x</thumbnail>').replace('<utube>','<link>https://www.youtube.com/watch?v=').replace('</utube>','</link>')#.replace('></','>x</')
		return link
	except: pass